# Mahesh Portfolio (Vite + React + Tailwind)

## Quick start
npm install
npm run dev

## Build
npm run build

## Deploy to GitHub Pages
1) Create repo: maheshpentapati.github.io
2) Commit & push this project
3) In GitHub → Settings → Pages → Deploy from a branch → Branch: main → Folder: / (root) OR /dist after building

## Assets to replace
- public/profile.jpg  ← your portrait (already added)
- public/resume.pdf   ← your resume (replace this file)
