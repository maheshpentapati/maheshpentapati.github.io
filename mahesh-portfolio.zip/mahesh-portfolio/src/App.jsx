import { useEffect, useMemo, useState } from "react";
import { motion, useScroll, useSpring } from "framer-motion";
import { ArrowUpRight, Mail, Github, Linkedin, Phone, Moon, Sun, Download, ExternalLink, Shield, Lock } from "lucide-react";

const data = {
  name: "Mahesh Babu Pentapati",
  tag: "SOC Analyst • FortiSIEM / FortiSOAR • Threat Hunting & Log Parsing",
  summary:
    "Cybersecurity professional focused on SOC operations, SIEM/SOAR engineering, and threat hunting. I build precise detections, robust parsers, and pragmatic automations.",
  links: {
    email: "maheshbabu.soc7@gmail.com",
    phone: "+91 7670866926",
    linkedin: "https://www.linkedin.com/in/mahesh-babu-pentapati-soc",
    github: "https://github.com/maheshpentapati",
    resume: "/resume.pdf",
  },
  photo: "/profile.jpg",
  experience: [
    {
      role: "SOC Analyst",
      org: "TechOwl",
      period: "Jun 2025 — Present",
      location: "Surat, Gujarat, India (On-site)",
      bullets: [
        "Cyber Threat Hunting (CTH), FortiSIEM engineering, SIEM/SOAR implementations",
        "Built detections, parsers, and automations for banking/financial clients",
        "Improved detection fidelity; executive-ready dashboards",
      ],
    },
    {
      role: "SOC Analyst",
      org: "Mastercard",
      period: "Sep 2022 — Jun 2025",
      location: "Pune, Maharashtra, India",
      bullets: [
        "QRadar-based monitoring, detection, response",
        "Correlation rule tuning to cut false positives",
        "Global SOC collaboration on hunts & IR exercises",
      ],
    },
  ],
  projects: [
    {
      title: "SQL Injection Detection Suite",
      desc: "Regex-based categories for time-based, boolean, and obfuscated payloads with noise reduction and coverage controls.",
      skills: ["FortiSIEM", "Regex", "MITRE ATT&CK", "Web"],
    },
    {
      title: "Windows DNS Flow Analytics (256/257/260/261)",
      desc: "Correlates query/response pairs to flag pointer loops, suspicious NXDOMAIN bursts, and potential exfiltration.",
      skills: ["Windows DNS", "Analytics", "Hunting"],
    },
    {
      title: "Trend Vision One Telemetry Normalization",
      desc: "Mapped connection/process/file telemetry into a unified SIEM schema for consistent detections & dashboards.",
      skills: ["TV1", "Mapping", "Dashboards"],
    },
    {
      title: "Phishing Simulation & Awareness",
      desc: "Designed & ran simulations; delivered training & metrics to leadership.",
      skills: ["Awareness", "Metrics"],
    },
  ],
  skills: [
    "Threat Hunting","Incident Response","FortiSIEM","FortiSOAR","QRadar","Splunk",
    "EDR/XDR","MITRE ATT&CK","Linux","Network Security","Packet Analysis (Wireshark)",
    "Vuln Mgmt","Firewalls / IDS/IPS","Cloud Sec (basics)","Python"
  ],
  certs: [
    { name: "Fortinet Certified Associate in Cybersecurity", org: "Fortinet", issued: "Jul 2025", expires: "Jul 2027", id: "2072677544MP" },
    { name: "NSE Level 1: Certified Associate", org: "Fortinet", issued: "Jul 2025" },
  ],
};

function useTheme() {
  const [theme, setTheme] = useState(
    () => localStorage.getItem("theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")
  );
  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    localStorage.setItem("theme", theme);
  }, [theme]);
  return { theme, setTheme };
}

function Section({ id, title, children, className = "" }) {
  return (
    <section id={id} className={`scroll-mt-24 py-14 sm:py-20 ${className}`} aria-labelledby={`${id}-h`}>
      <div className="mx-auto max-w-6xl px-5">
        <h2 id={`${id}-h`} className="text-2xl sm:text-3xl font-bold tracking-tight mb-6">{title}</h2>
        {children}
      </div>
    </section>
  );
}

function Pill({ children }) {
  return (
    <span className="inline-flex items-center rounded-full px-3 py-1 text-sm border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-900/40">
      {children}
    </span>
  );
}

function Card({ title, children, footer, href }) {
  const Comp = href ? "a" : "div";
  return (
    <Comp {...(href ? { href, target: "_blank", rel: "noreferrer" } : {})}
      className="group block rounded-2xl border border-zinc-200 dark:border-zinc-800 bg-white/70 dark:bg-zinc-900/60 backdrop-blur-sm p-6 hover:shadow-xl transition-shadow">
      <div className="flex items-start justify-between gap-4">
        <h3 className="text-lg font-semibold tracking-tight flex-1">{title}</h3>
        {href && <ExternalLink className="size-4 opacity-60 group-hover:opacity-100" />}
      </div>
      <div className="mt-2 text-sm/6 text-zinc-700 dark:text-zinc-300">{children}</div>
      {footer && <div className="mt-4 flex flex-wrap gap-2">{footer}</div>}
    </Comp>
  );
}

// Creative background
function GridBackground() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-20 [mask-image:radial-gradient(transparent,black_70%)]"
      style={{
        backgroundImage:
          "repeating-linear-gradient(0deg, rgba(120,120,120,0.06) 0px, rgba(120,120,120,0.06) 1px, transparent 1px, transparent 80px)," +
          "repeating-linear-gradient(90deg, rgba(120,120,120,0.06) 0px, rgba(120,120,120,0.06) 1px, transparent 1px, transparent 80px)",
        backgroundSize: "80px 80px, 80px 80px",
      }}
    />
  );
}
function GradientBlobs() {
  return (
    <div className="fixed inset-0 -z-30 overflow-hidden">
      <div className="absolute -top-40 -left-40 h-[42rem] w-[42rem] rounded-full blur-3xl opacity-30 bg-gradient-to-br from-indigo-500 via-cyan-400 to-emerald-400 dark:opacity-20" />
      <div className="absolute top-1/3 -right-40 h-[36rem] w-[36rem] rounded-full blur-3xl opacity-25 bg-gradient-to-br from-rose-400 via-fuchsia-400 to-indigo-400 dark:opacity-15" />
      <div className="absolute bottom-0 left-1/4 h-[28rem] w-[28rem] rounded-full blur-3xl opacity-25 bg-gradient-to-br from-amber-300 via-lime-300 to-emerald-300 dark:opacity-15" />
    </div>
  );
}
function CircuitOverlay() {
  return (
    <svg className="pointer-events-none fixed inset-0 -z-10 opacity-[0.10] dark:opacity-[0.12]" viewBox="0 0 1200 800" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="glow" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="#60a5fa"/><stop offset="100%" stopColor="#34d399"/>
        </linearGradient>
      </defs>
      {Array.from({ length: 40 }).map((_, i) => (
        <g key={i}>
          <path d={`M${(i*30)%1200} ${(i*18)%800} h70 v30 h40 v30`} stroke="url(#glow)" strokeWidth="1" fill="none" />
          <circle cx={(i*30+70)%1200} cy={(i*18)%800} r="2" fill="#22d3ee" />
        </g>
      ))}
    </svg>
  );
}
function FloatingLock() {
  return (
    <motion.div aria-hidden initial={{ y: -6 }} animate={{ y: 6 }} transition={{ repeat: Infinity, repeatType: "reverse", duration: 3 }}
      className="fixed right-4 bottom-6 z-40 rounded-2xl border border-zinc-200/60 dark:border-zinc-800/70 bg-white/60 dark:bg-zinc-900/50 backdrop-blur p-3 shadow-lg">
      <div className="flex items-center gap-2 text-xs"><Lock className="size-4"/><span className="opacity-70">Security-first</span></div>
    </motion.div>
  );
}

export default function Portfolio() {
  const { theme, setTheme } = useTheme();
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.2 });

  const nav = useMemo(
    () => [
      { id: "about", label: "About" },
      { id: "cyber", label: "Cyber Focus" },
      { id: "experience", label: "Experience" },
      { id: "projects", label: "Projects" },
      { id: "skills", label: "Skills" },
      { id: "certs", label: "Certifications" },
      { id: "contact", label: "Contact" },
    ],
    []
  );

  const onJump = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen relative bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100">
      <motion.div style={{ scaleX }} className="fixed left-0 right-0 top-0 h-1 origin-left bg-zinc-900/80 dark:bg-zinc-100/90 z-50" />
      <GradientBlobs />
      <GridBackground />
      <CircuitOverlay />
      <FloatingLock />

      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-zinc-200/70 dark:border-zinc-800/70 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-zinc-950/40">
        <div className="mx-auto max-w-6xl px-5 py-3 flex items-center justify-between gap-3">
          <button onClick={() => onJump('about')} className="font-bold text-lg tracking-tight focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 rounded" aria-label="Go to top">
            MB
          </button>
          <nav className="hidden md:flex items-center gap-1">
            {nav.map((n) => (
              <button key={n.id} onClick={() => onJump(n.id)} className="px-3 py-1.5 rounded-full text-sm hover:bg-zinc-100 dark:hover:bg-zinc-800/70 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500">
                {n.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            {data.links.linkedin && (
              <a href={data.links.linkedin} target="_blank" rel="noreferrer" className="p-2 rounded hover:bg-zinc-100 dark:hover:bg-zinc-800/70" aria-label="LinkedIn"><Linkedin className="size-5" /></a>
            )}
            {data.links.github && (
              <a href={data.links.github} target="_blank" rel="noreferrer" className="p-2 rounded hover:bg-zinc-100 dark:hover:bg-zinc-800/70" aria-label="GitHub"><Github className="size-5" /></a>
            )}
            <button onClick={() => setTheme(theme === "dark" ? "light" : "dark")} className="p-2 rounded hover:bg-zinc-100 dark:hover:bg-zinc-800/70 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500" aria-label="Toggle theme">
              {theme === "dark" ? <Sun className="size-5" /> : <Moon className="size-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <Section id="about" title={data.name}>
        <div className="grid md:grid-cols-5 gap-6 items-center">
          <div className="md:col-span-3">
            <div className="inline-flex items-center gap-2 rounded-full border border-zinc-300/70 dark:border-zinc-700/70 px-3 py-1 text-xs mb-3">
              <Shield className="size-3.5"/><span>Defensive Security • Detection Engineering</span>
            </div>
            <h3 className="text-lg sm:text-xl font-medium text-zinc-600 dark:text-zinc-300">{data.tag}</h3>
            <p className="mt-4 text-zinc-700 dark:text-zinc-300">{data.summary}</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <a href={`mailto:${data.links.email}`} className="inline-flex items-center gap-2 rounded-xl px-4 py-2 border border-zinc-300 dark:border-zinc-700 hover:shadow-lg">
                <Mail className="size-4" /> Email
              </a>
              {data.links.phone && (
                <a href={'tel:' + String(data.links.phone || '').split(' ').join('')} className="inline-flex items-center gap-2 rounded-xl px-4 py-2 border border-zinc-300 dark:border-zinc-700">
                  <Phone className="size-4" /> Call
                </a>
              )}
              {data.links.resume && data.links.resume !== "#" && (
                <a href={data.links.resume} download className="inline-flex items-center gap-2 rounded-xl px-4 py-2 border border-zinc-300 dark:border-zinc-700 hover:shadow-lg">
                  <Download className="size-4" /> Download Résumé
                </a>
              )}
            </div>
          </div>
          <div className="md:col-span-2 relative">
            <div className="absolute -inset-1 rounded-3xl blur-2xl opacity-40 bg-gradient-to-tr from-indigo-500 via-emerald-500 to-cyan-400" />
            <div className="relative aspect-square rounded-3xl bg-gradient-to-br from-zinc-100 to-zinc-50 dark:from-zinc-900 dark:to-zinc-950 border border-zinc-200 dark:border-zinc-800 overflow-hidden flex items-center justify-center text-6xl">
              {data.photo ? (
                <img src={data.photo} alt={data.name} className="h-full w-full object-cover" />
              ) : (
                <span className="font-extrabold">MB</span>
              )}
            </div>
          </div>
        </div>
      </Section>

      {/* Cyber Focus */}
      <Section id="cyber" title="Cyber Focus">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <Card title="Detection Engineering" footer={[<Pill key='p1'>ATT&CK TTPs</Pill>, <Pill key='p2'>Noise Control</Pill>, <Pill key='p3'>Coverage</Pill>]}>
            Build precise SIEM rules & parsers (FortiSIEM/QRadar/Splunk). Emphasis on fidelity, aggregation windows, and anti-evasion regex.
          </Card>
          <Card title="Incident Response" footer={[<Pill key='p4'>Triage</Pill>, <Pill key='p5'>Hunt</Pill>, <Pill key='p6'>IR Playbooks</Pill>]}>
            Rapid scoping with pivoting (process, network, identity). Documented playbooks for phishing, ransomware, and lateral movement.
          </Card>
          <Card title="Adversary Emulation" footer={[<Pill key='p7'>Atomic Red Team</Pill>, <Pill key='p8'>Caldera</Pill>]}>
            Safe simulations to validate detections (PowerShell/PsExec/MSHTA/Ngrok scenarios) mapped to ATT&CK.
          </Card>
          <Card title="SIEM Engineering" footer={[<Pill key='p9'>Data Models</Pill>, <Pill key='p10'>Dashboards</Pill>]}>
            Normalization, enrichment, and dashboards for executive reporting and SOC ops.
          </Card>
          <Card title="Threat Intel & Enrichment" footer={[<Pill key='p11'>AbuseIPDB</Pill>, <Pill key='p12'>VT</Pill>]}>
            Automated lookups and risk scoring to boost investigation speed.
          </Card>
          <Card title="Compliance & Reporting" footer={[<Pill key='p13'>RBI</Pill>, <Pill key='p14'>Audits</Pill>]}>
            Evidence-ready summaries, retention posture, and alert hygiene.
          </Card>
        </div>
      </Section>

      {/* Experience */}
      <Section id="experience" title="Experience">
        <div className="grid gap-4">
          {data.experience.map((e, i) => (
            <motion.div key={i} initial={{ y: 12, opacity: 0 }} whileInView={{ y: 0, opacity: 1 }} viewport={{ once: true }}
              transition={{ duration: 0.35, delay: i * 0.05 }}
              className="rounded-2xl border border-zinc-200 dark:border-zinc-800 p-6 bg-white/70 dark:bg-zinc-900/60">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h3 className="text-lg font-semibold">{e.role} — {e.org}</h3>
                <div className="text-sm text-zinc-600 dark:text-zinc-400">{e.period}</div>
              </div>
              <div className="text-sm mt-1 text-zinc-600 dark:text-zinc-400">{e.location}</div>
              <ul className="mt-3 list-disc pl-5 text-sm text-zinc-700 dark:text-zinc-300 space-y-1">
                {e.bullets.map((b, j) => <li key={j}>{b}</li>)}
              </ul>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* Projects */}
      <Section id="projects" title="Selected Projects">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {data.projects.map((p, i) => (
            <Card key={i} title={p.title} footer={p.skills.map((s, k) => (<Pill key={k}>{s}</Pill>))}>
              {p.desc}
            </Card>
          ))}
        </div>
      </Section>

      {/* Skills */}
      <Section id="skills" title="Skills">
        <div className="flex flex-wrap gap-2">{data.skills.map((s, i) => (<Pill key={i}>{s}</Pill>))}</div>
      </Section>

      {/* Certs */}
      <Section id="certs" title="Certifications">
        <div className="grid sm:grid-cols-2 gap-5">
          {data.certs.map((c, i) => (
            <Card key={i} title={c.name}>
              <div className="text-sm text-zinc-700 dark:text-zinc-300">
                <div><span className="opacity-70">Issuer:</span> {c.org}</div>
                {c.issued && <div><span className="opacity-70">Issued:</span> {c.issued}</div>}
                {c.expires && <div><span className="opacity-70">Expires:</span> {c.expires}</div>}
                {c.id && <div><span className="opacity-70">Credential ID:</span> {c.id}</div>}
              </div>
            </Card>
          ))}
        </div>
      </Section>

      {/* Contact */}
      <Section id="contact" title="Contact">
        <div className="grid md:grid-cols-2 gap-6 items-start">
          <div className="space-y-3">
            <a href={`mailto:${data.links.email}`} className="inline-flex items-center gap-2 p-3 rounded-xl border border-zinc-300 dark:border-zinc-700 w-full">
              <Mail className="size-4" /> {data.links.email}
            </a>
            {data.links.phone && (
              <a href={'tel:' + String(data.links.phone || '').split(' ').join('')} className="inline-flex items-center gap-2 p-3 rounded-xl border border-zinc-300 dark:border-zinc-700 w-full">
                <Phone className="size-4" /> {data.links.phone}
              </a>
            )}
            {data.links.linkedin && (
              <a href={data.links.linkedin} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 p-3 rounded-xl border border-zinc-300 dark:border-zinc-700 w-full">
                <Linkedin className="size-4" /> LinkedIn
              </a>
            )}
            {data.links.github && (
              <a href={data.links.github} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 p-3 rounded-xl border border-zinc-300 dark:border-zinc-700 w-full">
                <Github className="size-4" /> GitHub
              </a>
            )}
          </div>

          <form onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const name = fd.get("name");
              const email = fd.get("email");
              const msg = fd.get("message");
              window.location.href = `mailto:${data.links.email}?subject=Portfolio%20contact%20from%20${encodeURIComponent(String(name || ""))}&body=${encodeURIComponent(String(msg || ""))}%0A%0AFrom:%20${encodeURIComponent(String(email || ""))}`;
            }}
            className="rounded-2xl border border-zinc-200 dark:border-zinc-800 p-6 bg-white/70 dark:bg-zinc-900/60">
            <div className="grid gap-4">
              <div>
                <label className="block text-sm mb-1">Name</label>
                <input name="name" required className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-transparent px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div>
                <label className="block text-sm mb-1">Email</label>
                <input name="email" type="email" required className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-transparent px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <div>
                <label className="block text-sm mb-1">Message</label>
                <textarea name="message" rows={5} required className="w-full rounded-xl border border-zinc-300 dark:border-zinc-700 bg-transparent px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
              </div>
              <button className="inline-flex items-center gap-2 justify-center rounded-xl px-4 py-2 border border-zinc-300 dark:border-zinc-700 hover:shadow-lg">
                Send <ArrowUpRight className="size-4" />
              </button>
            </div>
          </form>
        </div>
      </Section>

      {/* Footer */}
      <footer className="py-10 border-t border-zinc-200 dark:border-zinc-800 text-sm">
        <div className="mx-auto max-w-6xl px-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} {data.name}. Built with ❤</p>
          <div className="flex items-center gap-3 opacity-80">
            <a href={data.links.linkedin} target="_blank" rel="noreferrer" className="underline-offset-4 hover:underline">LinkedIn</a>
            <a href={data.links.github} target="_blank" rel="noreferrer" className="underline-offset-4 hover:underline">GitHub</a>
            {data.links.resume && data.links.resume !== "#" && (
              <a href={data.links.resume} download className="underline-offset-4 hover:underline">Résumé</a>
            )}
          </div>
        </div>
      </footer>
    </div>
  );
}

function useScroll() { return { scrollYProgress: { onChange: () => {}, get: () => 0 } } } // placeholder for SSR safety in this static file
export { }
